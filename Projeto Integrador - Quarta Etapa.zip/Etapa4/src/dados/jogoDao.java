/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dados;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Deyse
 */
public class jogoDao {
    Connection conn;
    PreparedStatement st;
    
    public boolean conectar(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/multijogos","root", "1408");
            return true;
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("Erro ao conectar: " + ex.getMessage());
            return false;
        }
    }
    
    public int cadastrar(jogo j){
        int status;
        
        try {
            st = conn.prepareStatement("INSERT INTO jogos VALUES(?,?,?,?,?)");
            st.setInt(1, j.getid());
            st.setString(2,j.getnome());
            st.setString(3,j.getdata());
            st.setString(4,j.getcategoria());
            st.setString(5, j.getclas());
            status = st.executeUpdate();
            return status; 
        } catch (SQLException ex) {
            System.out.println("Erro ao conectar: " + ex.getMessage());
            return ex.getErrorCode();
        }
    }
    
    public void deletar (int id){
                
                String sql = "DELETE FROM jogos WHERE id = ?";
                try {
                    //esse trecho é igual ao método editar e inserir
                    PreparedStatement stmt = this.conn.prepareStatement(sql);
                    stmt.setInt(1, id);
                    
                    //Executando a query
                    stmt.execute();
                    //tratando o erro, caso ele ocorra
                } catch (Exception e) {
                    System.out.println("Erro ao excluir jogo: " + e.getMessage());
                }
                
            }
    
    
            public jogo getjogo(int id){
          String sql = "SELECT * FROM jogos WHERE id = ?";
      try {
                  
          PreparedStatement stmt = this.conn.prepareStatement(sql);
          stmt.setInt(1, id);
          ResultSet rs = stmt.executeQuery();
          
         
          jogo jogo = new jogo();
          rs.next();
          jogo.setid(id);
          jogo.setnome(rs.getString("nome"));
          jogo.setdata(rs.getString("datalancamento"));
          jogo.setcategoria(rs.getString("categoria"));
          jogo.setclas(rs.getString("classificacaoindicativa"));
          
      
          
          return jogo;
          
      } catch (Exception e) {
          System.out.println("erro: " + e.getMessage());
          return null;
      }
     }
        
     public List<jogo> getjogoP(String nomejogo){
          String sql = "SELECT * FROM jogos Where nome Like ?";
      try {
                  
          PreparedStatement stmt = this.conn.prepareStatement(sql);
         stmt.setString(1,"%" + nomejogo + "%");
          ResultSet rs = stmt.executeQuery();
          
          List<jogo> listajogos = new ArrayList<>();
        
       while (rs.next()){
          jogo jogo = new jogo();
         
          jogo.setid(rs.getInt("id"));
          jogo.setnome(rs.getString("nome"));
          jogo.setdata(rs.getString("datalancamento"));
          jogo.setcategoria(rs.getString("categoria"));
          jogo.setclas(rs.getString("classificacaoindicativa"));
          
          listajogos.add(jogo);
           
       }  
            return listajogos;
      } catch (Exception e) {
          System.out.println("erro: " + e.getMessage());
          return null;
      }
     }
         
     public List<jogo> getJogoPorId(int id1, int id2) {
                String sql = "SELECT * FROM jogos WHERE id >= ? AND id <= ?;"; 
                
                try {
                    PreparedStatement stmt = this.conn.prepareStatement(sql);
                                
                    stmt.setInt(1,id1);
                    stmt.setInt(2,id2 );
                    ResultSet rs = stmt.executeQuery();            
                    
                    List<jogo> listajogos = new ArrayList<>();
                    
                     while (rs.next()) { //.next retorna verdadeiro caso exista uma próxima posição dentro do array
                        jogo jogo = new jogo();
                        //Salvar dentro da variavel empresa, as informações            
                        jogo.setid(rs.getInt("id"));
                        jogo.setnome(rs.getString("nome"));
                        jogo.setdata(rs.getString("datalancamento"));
                        jogo.setcategoria(rs.getString("categoria"));
                        jogo.setclas(rs.getString("classificacaoindicativa"));
                        
                        listajogos.add(jogo);
                        
                    }
                      return listajogos;       
                } catch (Exception e) {
                    return null;
                }
            }
    
     public void desconectar(){
        try {
            conn.close();
        } catch (SQLException ex) {
            
        }    
     }
}
