
package dados;


public class usuario {
    String nome;
    String data;
    String senha;
    String tipo;
    int id;
    
    public usuario(){
    }
    
    public usuario(String nome, String data, String senha, String tipo){
        this.nome = nome;
        this.data = data;
        this.senha = senha;
        this.tipo = tipo;
    }
    
     public String getnome(){
        return nome;
    }
    
    public void setnome(String nome){
        this.nome = nome;
    }
    
    public String getdata(){
        return data;
    }
    
    public void setdata(String data){
        this.data = data;
    }
    
    public String getsenha(){
        return senha;
    }
    
    public void setsenha(String senha){
        this.senha = senha;
    }
    
    public String gettipo(){
        return tipo;
    }
    
    public void settipo(String tipo){
        this.tipo = tipo;
    }
    
     public int getid(){
        return id;
    }
    
    public void setid(int id){
        this.id = id;
    }
}
