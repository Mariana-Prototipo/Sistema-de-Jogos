

package principal;

import telas.telaUsuarioC;

public class main {

    public static void main(String[] args) {
        telaUsuarioC u = new telaUsuarioC();
        
        u.setVisible(true);
        
    }
}
