/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dados;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Deyse
 */
public class usuarioDao {
     Connection conn;
    PreparedStatement st;
    
    public boolean conectar(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/multijogos","root", "1408");
            return true;
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("Erro ao conectar: " + ex.getMessage());
            return false;
        }
    }

    public int salvar(usuario u){
        int status;
        
        try {
            st = conn.prepareStatement("INSERT INTO usuario VALUES(?,?,?,?,?)");
            st.setInt(1, u.getid());
            st.setString(2,u.getnome());
            st.setString(3,u.getdata());
            st.setString(4,u.getsenha());
            st.setString(5,u.gettipo());
            status = (int) st.executeLargeUpdate();
            return status; 
        } catch (SQLException ex) {
            System.out.println("Erro ao conectar: " + ex.getMessage());
            return ex.getErrorCode();
        }
    }
    
    public int validarusuario(usuario u){
           int status;
        try{
            String SQL = " SELECT usuario, senha FROM usuarios  WHERE usuario = ?  and senha = ?";
                st = conn.prepareStatement(SQL);
                st.setString(1, u.getnome());
                st.setString(1, u.getsenha());
                status = st.executeUpdate();
                return status;
        }catch (SQLException ex) {
            System.out.println("Erro ao conectar: " + ex.getMessage());
            return ex.getErrorCode();
        }
    }
    
    public void deletar (int id){
                
                String sql = "DELETE FROM usuario WHERE id = ?";
                try {
                    //esse trecho é igual ao método editar e inserir
                    PreparedStatement stmt = this.conn.prepareStatement(sql);
                    stmt.setInt(1, id);
                    
                    //Executando a query
                    stmt.execute();
                    //tratando o erro, caso ele ocorra
                } catch (Exception e) {
                    System.out.println("Erro ao excluir jogo: " + e.getMessage());
                }
                
            }
    
    
     public void desconectar(){
        try {
            conn.close();
        } catch (SQLException ex) {
            
        }    
     }
}
