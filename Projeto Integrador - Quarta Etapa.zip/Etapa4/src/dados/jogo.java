
package dados;


public class jogo {
    private String nome;
    private String data;
    private String categoria;
    private String clas;
    private int id;
    
    public jogo(){
        
    }
    
    public jogo(String nome, String data, String categoria, String clas){
        this.nome = nome;
        this.data = data;
        this.categoria = categoria;
        this.clas = clas;
        
    }
    
    public String getnome(){
        return nome;
    }
    
    public void setnome(String nome){
        this.nome = nome;
    }
    
    public String getdata(){
        return data;
    }
    
    public void setdata(String data){
        this.data = data;
    }
    
    public String getcategoria(){
        return categoria;
    }
    
    public void setcategoria(String categoria){
        this.categoria = categoria;
    }
    
    public String getclas(){
        return clas;
    }
    
    public void setclas(String clas){
        this.clas = clas;
    }
    
    public int getid(){
        return id;
    }
    
    public void setid(int id){
        this.id = id;
    }
}
